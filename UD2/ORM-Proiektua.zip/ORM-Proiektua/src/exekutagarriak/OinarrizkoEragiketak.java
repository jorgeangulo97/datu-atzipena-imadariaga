package exekutagarriak;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import model.Artist;

public class OinarrizkoEragiketak {

	public static SessionFactory sf = new Configuration().configure().buildSessionFactory();

	public static void main(String[] args) {

		datuaGorde(new Artist(276, "Jorge"));
                datuaGorde(new Artist(277, "Aritz"));
		datuakIkusi();
	}

	public static void datuaGorde(Artist a) {

		Session saioa = sf.openSession();
		saioa.beginTransaction();
		saioa.save(a);
		saioa.getTransaction().commit();
		saioa.close();

	}

	public static void datuakIkusi() {

		Session saioa = sf.openSession();
		saioa.beginTransaction();
		List result = saioa.createQuery("from Artist").list(); // HQL deitzen dan lengoaia idatziko dugu Querya
		for (Artist a : (List<Artist>) result) {
			System.out.println(a);
		}
		saioa.getTransaction().commit();
		saioa.close();
	}
}