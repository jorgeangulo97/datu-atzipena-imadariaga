
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import javax.json.Json;
import javax.json.stream.JsonGenerator;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author imadariaga
 */
public class HistorialakKudeatu {

    static Document xmlDOM;
    
    public static void main(String[] args) {
        String xmlFileIn = "Historialak.xml";//XML hasierako fitxategia
        String csvFileIn = "HistorialGehiago.csv";//Gehitu beharreko fitxategiak, .csv formatuan
        String xmlFileOut = "HistorialGuztiak.xml";//Aurreko bien batura
        String jsonFileOut = "Historialak.json";//Sarrera objetuen array bat 
                
/*  Metodoak programatzen joan ala, hurrengo lerroak deskomentatuz joan.          
                
       //BAT: XML fitxategiko datuak memorian, DOM fitxategi baten kargatu
        xmlDOM = xmlFitxategiaMemorianKargatu(xmlFileIn);

        //BI: CSV fitxategi baten dauzkagun datuak DOM zuhaitzera gehitu
        datuakGehitu(csvFileIn);

        //HIRU: Orainarte dauden positiboak zenbatu eta inprimatu
        System.out.println("Orainarte daukagun positibo kopurua: " + positiboKopurua());

        //LAU: XML formatuko fitxategi baten gorde
        if (historialakXMLnGorde(xmlFileOut)) {
            System.out.println(xmlFileOut + " ondo gorde da.");
        }

        //BOST: Ikaslea eskatu eta bere datuak .csv formatuan gorde.        
        Scanner sc = new Scanner(System.in);
        System.out.print("Zein ikasleren historiala nahi duzu ikusi? ");
        String ikaslea = sc.next();
        ikasleBatenHistorialaCsvra(ikaslea);

        //SEI: Datuak Json formatuan esportatu. Zuzenean DOM zuhaitzetik, StreamParser erabilita
        if (historialakJsonera(jsonFileOut)) {
            System.out.println("Datuak ondo esportatu dira " + jsonFileOut + " fitxategira.");
        }
*/        
    }


}
